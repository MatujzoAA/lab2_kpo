using System;

public class Game
{
    private readonly int fieldSize;
    public Player Cat { get; }
    public Player Mouse { get; }

    public Game(int fieldSize)
    {
        this.fieldSize = fieldSize;
        Cat = new Player("Cat");
        Mouse = new Player("Mouse");
    }

    public void SetInitialPosition(string playerType, int position)
    {
        if (playerType == "M")
            Mouse.SetPosition(position, fieldSize);
        else if (playerType == "C")
            Cat.SetPosition(position, fieldSize);
    }

    public void MovePlayer(string playerType, int steps)
    {
        if (playerType == "M" && Mouse.Status == "Playing")
            Mouse.Move(steps, fieldSize);
        else if (playerType == "C" && Cat.Status == "Playing")
            Cat.Move(steps, fieldSize);
    }

    public void PrintState()
    {
        Console.WriteLine("Cat and Mouse\n");
        Console.WriteLine("Cat    Mouse    Distance");
        Console.WriteLine("------------------------");
        Console.WriteLine($"{(Cat.Position.HasValue ? Cat.Position.ToString() : "??")}    {(Mouse.Position.HasValue ? Mouse.Position.ToString() : "??")}    {CalculateDistance()}");
        Console.WriteLine("------------------------");
    }

    public int? CalculateDistance()
    {
        if (!Cat.Position.HasValue || !Mouse.Position.HasValue)
            return null;

        int distance = Math.Abs(Cat.Position.Value - Mouse.Position.Value);
        return Math.Min(distance, fieldSize - distance);
    }

    public bool CheckGameOver()
    {
        if (Cat.Position == Mouse.Position)
        {
            Cat.SetStatus("Winner");
            Mouse.SetStatus("Loser");
            Console.WriteLine($"Мышь поймана в клетке: {Cat.Position} - Mouse caught at: {Cat.Position}");
            return true;
        }
        return false;
    }
}