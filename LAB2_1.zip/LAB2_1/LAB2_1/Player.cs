using System;

public class Player
{
    public string Name { get; }
    public int? Position { get; private set; }
    public int DistanceTraveled { get; private set; }
    private string status; // Закрытое поле для статуса

    public string Status => status; // Только геттер для свойства Status

    public Player(string name)
    {
        Name = name;
        Position = null;
        DistanceTraveled = 0;
        status = "NotInGame";
    }

    public void SetPosition(int position, int fieldSize)
    {
        Position = position % fieldSize;
        status = "Playing";
    }

    public void Move(int steps, int fieldSize)
    {
        if (Position.HasValue)
        {
            Position = (Position.Value + steps + fieldSize) % fieldSize;
            DistanceTraveled += Math.Abs(steps);
        }
    }

    public void SetStatus(string newStatus)
    {
        status = newStatus;
    }

    public override string ToString()
    {
        string posStr = Position.HasValue ? Position.Value.ToString() : "??";
        return $"{Name}: Position={posStr}, Distance={DistanceTraveled}, Status={status}";
    }
}