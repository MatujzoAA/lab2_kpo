﻿using System;
using System.IO;

public class Program
{
    public static void Main()
    {
        string inputFilePath = "ChaseData3.txt";

        if (!File.Exists(inputFilePath))
        {
            Console.WriteLine("Файл данных не найден.");
            return;
        }

        string[] lines = File.ReadAllLines(inputFilePath);
        int fieldSize = int.Parse(lines[0].Trim());

        Game game = new Game(fieldSize);

        foreach (string line in lines[1..])
        {
            string[] parts = line.Trim().Split(new[] {' '}, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 0) continue; // Пропускаем пустые строки

            string command = parts[0];

            if ((command == "M" || command == "C") && parts.Length == 2)
            {
                int value = int.Parse(parts[1]);
                
                // Устанавливаем начальную позицию, если она еще не задана
                if (command == "M" && game.Mouse.Position == null)
                {
                    game.SetInitialPosition(command, value);
                }
                else if (command == "C" && game.Cat.Position == null)
                {
                    game.SetInitialPosition(command, value);
                }
                else
                {
                    // Выполняем перемещение, если позиции заданы
                    game.MovePlayer(command, value);
                }
            }
            else if (command == "P")
            {
                game.PrintState();
            }

            // Проверяем конец игры после каждого перемещения или команды
            if (game.CheckGameOver())
                break;
        }

        Console.WriteLine("\nПройденное расстояние:");
        Console.WriteLine($"Cat: {game.Cat.DistanceTraveled}");
        Console.WriteLine($"Mouse: {game.Mouse.DistanceTraveled}");

        // Сообщение, если кот не поймал мышь
        if (game.Cat.Status != "Winner")
        {
            Console.WriteLine("Мышь ускользнула от кота - Mouse evaded Cat");
        }
    }
}
